# Permission to Relicense under MPLv2 or any other OSI approved license chosen by the current ZeroMQ BDFL

This is a statement by JaeSang Yoo
that grants permission to relicense its copyrights in the libzmq C++
library (ZeroMQ) under the Mozilla Public License v2 (MPLv2) or any other 
Open Source Initiative approved license chosen by the current ZeroMQ 
BDFL (Benevolent Dictator for Life).

A portion of the commits made by the Github handle "JSYoo5B", with
commit author "JaeSang Yoo <jsyoo5b@gmail.com>", are copyright of JaeSang Yoo.
This document hereby grants the libzmq project team to relicense libzmq, 
including all past, present and future contributions of the author listed above.

JaeSang Yoo  
2020.02.29
