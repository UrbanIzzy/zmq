# Permission to Relicense under MPLv2

This is a statement by Telford Berkey
that grants permission to relicense its copyrights in the libzmq C++
library (ZeroMQ) under the Mozilla Public License v2 (MPLv2).

A portion of the commits made by the Github handle "tberkey", with
commit author "Telford Berkey <tberkey@gmail.com>", are copyright of Telford Berkey.
This document hereby grants the libzmq project team to relicense libzmq, 
including all past, present and future contributions of the author listed above.

Telford Berkey

03 Feb 2020
